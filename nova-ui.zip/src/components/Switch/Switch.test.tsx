import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { Switch } from './Switch';

describe('Switch', () => {
  it('renders label', () => {
    render(<Switch label="Airplane Mode" />);
    expect(screen.getByText('Airplane Mode')).toBeInTheDocument();
  });

  it('toggles on click', () => {
    const handleChange = vi.fn();
    render(<Switch onCheckedChange={handleChange} />);
    fireEvent.click(screen.getByRole('switch'));
    expect(handleChange).toHaveBeenCalledWith(true);
  });

  it('is disabled when disabled prop is true', () => {
    render(<Switch disabled label="Disabled" />);
    expect(screen.getByRole('switch')).toBeDisabled();
  });

  it('shows description', () => {
    render(<Switch label="Notifications" description="Receive push notifications" />);
    expect(screen.getByText('Receive push notifications')).toBeInTheDocument();
  });
});
