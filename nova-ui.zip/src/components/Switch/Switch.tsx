import React, { forwardRef } from 'react';
import { cn } from '../../lib/utils';

export interface SwitchProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type' | 'role'> {
  /** Label text */
  label?: string;
  /** Description text */
  description?: string;
  /** Size */
  size?: 'sm' | 'md' | 'lg';
  /** Checked state (controlled) */
  checked?: boolean;
  /** Default checked (uncontrolled) */
  defaultChecked?: boolean;
  /** Change handler */
  onCheckedChange?: (checked: boolean) => void;
}

const sizeStyles = {
  sm: { track: 'h-5 w-9', thumb: 'h-3.5 w-3.5', translate: 'translate-x-4' },
  md: { track: 'h-6 w-11', thumb: 'h-4.5 w-4.5', translate: 'translate-x-5' },
  lg: { track: 'h-7 w-13', thumb: 'h-5.5 w-5.5', translate: 'translate-x-6' },
};

export const Switch = forwardRef<HTMLInputElement, SwitchProps>(
  (
    { className, label, description, size = 'md', checked, defaultChecked, onCheckedChange, disabled, id, ...props },
    ref
  ) => {
    const switchId = id || `switch-${Math.random().toString(36).slice(2, 9)}`;
    const styles = sizeStyles[size];

    return (
      <div className={cn('flex items-start gap-3', className)}>
        <div className="relative inline-flex flex-shrink-0">
          <input
            ref={ref}
            type="checkbox"
            role="switch"
            id={switchId}
            checked={checked}
            defaultChecked={defaultChecked}
            disabled={disabled}
            onChange={(e) => onCheckedChange?.(e.target.checked)}
            className="peer sr-only"
            {...props}
          />
          <label
            htmlFor={switchId}
            className={cn(
              'relative inline-flex cursor-pointer rounded-full transition-colors duration-200',
              'bg-gray-200 peer-checked:bg-primary-600',
              'peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary-500/20',
              'peer-disabled:cursor-not-allowed peer-disabled:opacity-50',
              styles.track
            )}
          >
            <span
              className={cn(
                'absolute left-0.5 top-1/2 -translate-y-1/2 rounded-full bg-white shadow-sm transition-transform duration-200',
                'peer-checked:' + styles.translate,
                styles.thumb
              )}
            />
          </label>
        </div>
        {(label || description) && (
          <div className="flex flex-col">
            {label && (
              <label htmlFor={switchId} className={cn('text-sm font-medium text-gray-900', disabled && 'opacity-50')}>
                {label}
              </label>
            )}
            {description && <p className="text-sm text-gray-500">{description}</p>}
          </div>
        )}
      </div>
    );
  }
);

Switch.displayName = 'Switch';
