import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { Modal } from './Modal';

describe('Modal', () => {
  it('does not render when closed', () => {
    render(<Modal isOpen={false} onClose={() => {}} title="Test" />);
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('renders when open', () => {
    render(<Modal isOpen={true} onClose={() => {}} title="Test Modal" />);
    expect(screen.getByRole('dialog')).toBeInTheDocument();
    expect(screen.getByText('Test Modal')).toBeInTheDocument();
  });

  it('calls onClose when close button clicked', () => {
    const handleClose = vi.fn();
    render(<Modal isOpen={true} onClose={handleClose} title="Test" />);
    fireEvent.click(screen.getByLabelText('Close modal'));
    expect(handleClose).toHaveBeenCalledTimes(1);
  });

  it('renders custom footer', () => {
    render(
      <Modal isOpen={true} onClose={() => {}} footer={<button>Custom</button>}>
        Content
      </Modal>
    );
    expect(screen.getByText('Custom')).toBeInTheDocument();
  });

  it('hides default footer when footer is null', () => {
    render(
      <Modal isOpen={true} onClose={() => {}} footer={null}>
        Content
      </Modal>
    );
    expect(screen.queryByText('Cancel')).not.toBeInTheDocument();
  });
});
