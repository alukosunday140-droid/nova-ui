import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from './Card';

describe('Card', () => {
  it('renders children', () => {
    render(<Card>Card content</Card>);
    expect(screen.getByText('Card content')).toBeInTheDocument();
  });

  it('applies elevation classes', () => {
    const { rerender } = render(<Card elevation="lg">Test</Card>);
    expect(screen.getByText('Test')).toHaveClass('shadow-lg');

    rerender(<Card elevation="none">Test</Card>);
    expect(screen.getByText('Test')).not.toHaveClass('shadow-md');
  });

  it('renders compound components', () => {
    render(
      <Card>
        <CardHeader>
          <CardTitle>Title</CardTitle>
          <CardDescription>Description</CardDescription>
        </CardHeader>
        <CardContent>Content</CardContent>
        <CardFooter>Footer</CardFooter>
      </Card>
    );

    expect(screen.getByText('Title')).toHaveClass('font-semibold');
    expect(screen.getByText('Description')).toHaveClass('text-gray-500');
    expect(screen.getByText('Footer').parentElement).toHaveClass('flex');
  });
});
