import type { Meta, StoryObj } from '@storybook/react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from './Card';
import { Button } from '../Button';

const meta: Meta<typeof Card> = {
  title: 'Components/Card',
  component: Card,
  parameters: { layout: 'centered' },
  tags: ['autodocs'],
  argTypes: {
    elevation: { control: 'select', options: ['none', 'sm', 'md', 'lg'] },
    padding: { control: 'select', options: ['none', 'sm', 'md', 'lg'] },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: (args) => (
    <Card {...args} className="w-96">
      <CardHeader>
        <CardTitle>Project Settings</CardTitle>
        <CardDescription>Manage your project preferences and team access.</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-gray-600">Configure deployment settings, environment variables, and notification preferences.</p>
      </CardContent>
      <CardFooter>
        <Button variant="primary" size="sm">Save Changes</Button>
        <Button variant="ghost" size="sm">Cancel</Button>
      </CardFooter>
    </Card>
  ),
};

export const Clickable: Story = {
  args: { clickable: true, hover: true, className: 'w-80 cursor-pointer' },
  render: (args) => (
    <Card {...args}>
      <CardContent>
        <CardTitle className="mb-2">Upgrade Plan</CardTitle>
        <p className="text-sm text-gray-600">Click to view available plans and pricing.</p>
      </CardContent>
    </Card>
  ),
};

export const NoPadding: Story = {
  args: { padding: 'none', className: 'w-80 overflow-hidden' },
  render: (args) => (
    <Card {...args}>
      <div className="h-32 bg-gradient-to-br from-primary-500 to-primary-700" />
      <div className="p-6">
        <CardTitle className="mb-1">Featured</CardTitle>
        <p className="text-sm text-gray-600">Card with no padding on the container.</p>
      </div>
    </Card>
  ),
};
