import type { Meta, StoryObj } from '@storybook/react';
import { Input } from './Input';

const meta: Meta<typeof Input> = {
  title: 'Components/Input',
  component: Input,
  parameters: { layout: 'centered' },
  tags: ['autodocs'],
  argTypes: {
    size: { control: 'select', options: ['sm', 'md', 'lg'] },
    type: { control: 'select', options: ['text', 'email', 'password', 'number'] },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: { placeholder: 'Type something...' },
};

export const WithLabel: Story = {
  args: { label: 'Email Address', placeholder: 'you@example.com', type: 'email' },
};

export const WithError: Story = {
  args: { label: 'Password', error: 'Password must be at least 8 characters', type: 'password' },
};

export const WithHelper: Story = {
  args: { label: 'Username', helperText: 'This will be your public display name' },
};

export const Disabled: Story = {
  args: { label: 'API Key', value: 'sk-abc123', disabled: true },
};

export const WithIcons: Story = {
  args: {
    label: 'Search',
    placeholder: 'Search...',
    leftElement: (
      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
      </svg>
    ),
    rightElement: (
      <kbd className="rounded border border-gray-200 bg-gray-50 px-1.5 text-xs text-gray-500">⌘K</kbd>
    ),
  },
};

export const Small: Story = { args: { size: 'sm', placeholder: 'Small input' } };
export const Large: Story = { args: { size: 'lg', placeholder: 'Large input' } };
