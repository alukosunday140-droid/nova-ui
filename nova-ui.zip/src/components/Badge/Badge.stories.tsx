import type { Meta, StoryObj } from '@storybook/react';
import { Badge } from './Badge';

const meta: Meta<typeof Badge> = {
  title: 'Components/Badge',
  component: Badge,
  parameters: { layout: 'centered' },
  tags: ['autodocs'],
  argTypes: {
    variant: { control: 'select', options: ['default', 'primary', 'success', 'warning', 'danger', 'info'] },
    size: { control: 'select', options: ['sm', 'md'] },
    rounded: { control: 'select', options: ['full', 'md'] },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = { args: { children: 'Badge' } };
export const Primary: Story = { args: { variant: 'primary', children: 'Primary' } };
export const Success: Story = { args: { variant: 'success', children: 'Success' } };
export const Warning: Story = { args: { variant: 'warning', children: 'Warning' } };
export const Danger: Story = { args: { variant: 'danger', children: 'Danger' } };
export const Info: Story = { args: { variant: 'info', children: 'Info' } };

export const WithDot: Story = {
  args: { variant: 'success', dot: true, children: 'Live' },
};

export const Small: Story = {
  args: { size: 'sm', variant: 'primary', children: 'Small' },
};

export const Rounded: Story = {
  args: { rounded: 'md', variant: 'primary', children: 'Rounded' },
};
