import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Select } from './Select';

const meta: Meta<typeof Select> = {
  title: 'Components/Select',
  component: Select,
  parameters: { layout: 'centered' },
  tags: ['autodocs'],
  argTypes: {
    size: { control: 'select', options: ['sm', 'md', 'lg'] },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const options = [
  { value: 'us', label: 'United States' },
  { value: 'uk', label: 'United Kingdom' },
  { value: 'ca', label: 'Canada' },
  { value: 'au', label: 'Australia' },
  { value: 'jp', label: 'Japan', disabled: true },
];

export const Default: Story = {
  render: (args) => {
    const [value, setValue] = useState('');
    return <Select {...args} options={options} value={value} onChange={setValue} label="Country" placeholder="Select a country" />;
  },
};

export const WithError: Story = {
  args: { options, label: 'Role', error: 'Please select a role', placeholder: 'Select role' },
};

export const Disabled: Story = {
  args: { options, disabled: true, label: 'Status', value: 'us' },
};

export const Small: Story = {
  args: { options, size: 'sm', label: 'Size Small' },
};

export const Large: Story = {
  args: { options, size: 'lg', label: 'Size Large' },
};
