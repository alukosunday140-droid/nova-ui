import React, { forwardRef } from 'react';
import { cn } from '../../lib/utils';

export interface AvatarProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Image source URL */
  src?: string;
  /** Alt text for image */
  alt?: string;
  /** Fallback initials or text */
  fallback?: string;
  /** Size */
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  /** Shape */
  shape?: 'circle' | 'square';
  /** Status indicator */
  status?: 'online' | 'offline' | 'away' | 'busy';
  /** Border */
  bordered?: boolean;
}

const sizeStyles = {
  xs: 'h-6 w-6 text-[10px]',
  sm: 'h-8 w-8 text-xs',
  md: 'h-10 w-10 text-sm',
  lg: 'h-12 w-12 text-base',
  xl: 'h-14 w-14 text-lg',
  '2xl': 'h-16 w-16 text-xl',
};

const statusColors = {
  online: 'bg-green-500',
  offline: 'bg-gray-400',
  away: 'bg-yellow-500',
  busy: 'bg-red-500',
};

export const Avatar = forwardRef<HTMLDivElement, AvatarProps>(
  ({ className, src, alt, fallback, size = 'md', shape = 'circle', status, bordered, ...props }, ref) => {
    const [hasError, setHasError] = React.useState(false);

    const showFallback = !src || hasError;
    const initials = fallback
      ?.split(' ')
      .map((n) => n[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();

    return (
      <div className="relative inline-block" ref={ref}>
        <div
          className={cn(
            'relative flex items-center justify-center overflow-hidden bg-gray-200 font-medium text-gray-600',
            shape === 'circle' ? 'rounded-full' : 'rounded-lg',
            sizeStyles[size],
            bordered && 'ring-2 ring-white',
            className
          )}
          {...props}
        >
          {!showFallback ? (
            <img
              src={src}
              alt={alt || fallback || 'Avatar'}
              className="h-full w-full object-cover"
              onError={() => setHasError(true)}
            />
          ) : (
            <span>{initials || fallback?.slice(0, 2).toUpperCase() || '?'}</span>
          )}
        </div>
        {status && (
          <span
            className={cn(
              'absolute bottom-0 right-0 block rounded-full ring-2 ring-white',
              statusColors[status],
              size === 'xs' || size === 'sm' ? 'h-2 w-2' : 'h-3 w-3'
            )}
          />
        )}
      </div>
    );
  }
);

Avatar.displayName = 'Avatar';

export interface AvatarGroupProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Max avatars to show before +N */
  max?: number;
  /** Spacing between avatars */
  spacing?: 'sm' | 'md' | 'lg';
}

export const AvatarGroup = forwardRef<HTMLDivElement, AvatarGroupProps>(
  ({ className, children, max, spacing = 'md', ...props }, ref) => {
    const childrenArray = React.Children.toArray(children);
    const showMax = max !== undefined && childrenArray.length > max;
    const visibleChildren = showMax ? childrenArray.slice(0, max) : childrenArray;
    const remaining = childrenArray.length - (max || 0);

    const spacingStyles = {
      sm: '-space-x-1',
      md: '-space-x-2',
      lg: '-space-x-3',
    };

    return (
      <div className={cn('flex items-center', spacingStyles[spacing], className)} ref={ref} {...props}>
        {visibleChildren.map((child, index) =>
          React.cloneElement(child as React.ReactElement, {
            key: index,
            className: cn(
              (child as React.ReactElement).props.className,
              'ring-2 ring-white'
            ),
          })
        )}
        {showMax && remaining > 0 && (
          <div
            className={cn(
              'flex items-center justify-center rounded-full bg-gray-100 font-medium text-gray-600 ring-2 ring-white',
              sizeStyles.md
            )}
          >
            +{remaining}
          </div>
        )}
      </div>
    );
  }
);

AvatarGroup.displayName = 'AvatarGroup';
