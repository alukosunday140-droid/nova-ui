import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Textarea } from './Textarea';

const meta: Meta<typeof Textarea> = {
  title: 'Components/Textarea',
  component: Textarea,
  parameters: { layout: 'centered' },
  tags: ['autodocs'],
  argTypes: {
    size: { control: 'select', options: ['sm', 'md', 'lg'] },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: (args) => {
    const [value, setValue] = useState('');
    return <Textarea {...args} value={value} onChange={(e) => setValue(e.target.value)} label="Description" placeholder="Enter a description..." />;
  },
};

export const WithCount: Story = {
  render: (args) => {
    const [value, setValue] = useState('');
    return (
      <Textarea
        {...args}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        label="Bio"
        showCount
        maxLength={200}
        helperText="Brief description for your profile."
      />
    );
  },
};

export const AutoResize: Story = {
  render: (args) => {
    const [value, setValue] = useState('');
    return (
      <Textarea
        {...args}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        label="Auto-resize"
        autoResize
        placeholder="Type multiple lines..."
      />
    );
  },
};

export const WithError: Story = {
  args: { label: 'Feedback', error: 'This field is required', placeholder: 'Your feedback' },
};

export const Disabled: Story = {
  args: { label: 'Notes', disabled: true, value: 'Cannot edit this' },
};
