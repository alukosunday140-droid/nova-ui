import React, { forwardRef } from 'react';
import { cn } from '../../lib/utils';

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  /** Label text */
  label?: string;
  /** Error message */
  error?: string;
  /** Helper text */
  helperText?: string;
  /** Visual size */
  size?: 'sm' | 'md' | 'lg';
  /** Full width */
  fullWidth?: boolean;
  /** Character count */
  showCount?: boolean;
  /** Maximum characters */
  maxLength?: number;
  /** Auto-resize height */
  autoResize?: boolean;
}

const sizeStyles = {
  sm: 'px-3 py-2 text-sm min-h-[80px]',
  md: 'px-4 py-2.5 text-base min-h-[100px]',
  lg: 'px-4 py-3 text-lg min-h-[120px]',
};

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  (
    {
      className,
      label,
      error,
      helperText,
      size = 'md',
      fullWidth = false,
      showCount = false,
      maxLength,
      autoResize = false,
      id,
      onInput,
      ...props
    },
    ref
  ) => {
    const textareaId = id || `textarea-${Math.random().toString(36).slice(2, 9)}`;
    const currentLength = (props.value as string)?.length || 0;

    const handleInput = (e: React.FormEvent<HTMLTextAreaElement>) => {
      if (autoResize) {
        const target = e.currentTarget;
        target.style.height = 'auto';
        target.style.height = `${target.scrollHeight}px`;
      }
      onInput?.(e);
    };

    return (
      <div className={cn('flex flex-col gap-1.5', fullWidth && 'w-full')}>
        {label && (
          <label htmlFor={textareaId} className="text-sm font-medium text-gray-700">
            {label}
          </label>
        )}
        <textarea
          ref={ref}
          id={textareaId}
          className={cn(
            'resize-y rounded-lg border border-gray-300 bg-white text-gray-900',
            'transition-colors duration-200',
            'placeholder:text-gray-400',
            'focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-500/20',
            'disabled:cursor-not-allowed disabled:bg-gray-50 disabled:text-gray-400',
            error && 'border-red-500 focus:border-red-500 focus:ring-red-500/20',
            autoResize && 'resize-none overflow-hidden',
            sizeStyles[size],
            fullWidth && 'w-full',
            className
          )}
          maxLength={maxLength}
          onInput={handleInput}
          aria-invalid={error ? 'true' : 'false'}
          aria-describedby={
            error ? `${textareaId}-error` : helperText ? `${textareaId}-helper` : undefined
          }
          {...props}
        />
        <div className="flex justify-between">
          {(error || helperText) && (
            <p
              id={error ? `${textareaId}-error` : `${textareaId}-helper`}
              className={cn('text-sm', error ? 'text-red-600' : 'text-gray-500')}
            >
              {error || helperText}
            </p>
          )}
          {showCount && maxLength && (
            <p className={cn('ml-auto text-sm text-gray-400', error && 'text-red-400')}>
              {currentLength}/{maxLength}
            </p>
          )}
        </div>
      </div>
    );
  }
);

Textarea.displayName = 'Textarea';
