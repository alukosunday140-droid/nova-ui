import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { Textarea } from './Textarea';

describe('Textarea', () => {
  it('renders with label', () => {
    render(<Textarea label="Bio" />);
    expect(screen.getByLabelText('Bio')).toBeInTheDocument();
  });

  it('shows character count', () => {
    render(<Textarea showCount maxLength={200} value="Hello" />);
    expect(screen.getByText('5/200')).toBeInTheDocument();
  });

  it('displays error', () => {
    render(<Textarea error="Too long" />);
    expect(screen.getByText('Too long')).toHaveClass('text-red-600');
  });

  it('is disabled', () => {
    render(<Textarea disabled />);
    expect(screen.getByRole('textbox')).toBeDisabled();
  });
});
